# gulp-dev

Install:

1. Clone or download repository
2. npm i
3. gulp dev

---

Now you have Browser Sync, Pug, Stylus, Autoprefixer, jQuery, Bootstrap Reboot

Folder src/ for PSD templates, JPG previews etc.

Folder app/ for Pug and Stylus files. app/pug/index.pug will transpiled to dist/index.html. app/styl/main.styl will transpiled to dist/css/main.css

Folder dist/ - distributive folder - here transpiled index.html and css/main.css, and you can add here other CSS, JS, IMG, FONTS files

Have a nice coding :)
